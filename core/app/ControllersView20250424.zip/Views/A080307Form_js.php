    <!-- DataTables -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>

    <script src="<?php echo base_url() ?>/plugins/jasny/jasny-bootstrap.js"></script>
    <!-- bootstrap time picker -->
    <script src="<?php echo base_url() ?>/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <!-- wysuhtml5 Plugin JavaScript -->
    <script src="<?php echo base_url() ?>/plugins/summernote/dist/summernote-bs4.min.js"></script>
    <!-- image-uploader -->
    <script src="<?php echo base_url() ?>/plugins/image-uploader/image-uploader.min.js"></script>
    <script src="<?php echo base_url() ?>/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/plugins/jasny/jasny-bootstrap.js"></script>

<!-- Script jQuery dan Tagify -->
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify@4.6.0/dist/tagify.min.js"></script>


    <script type="text/javascript">
    	$(document).ready(function() {
    		var base_url_class = "<?php echo $base_url_class  ?>",
    			base_url = "<?php echo base_url()  ?>",
    			default_main_segmen = "<?php echo $default_main_content_type  ?>",
    			page_href = window.location.pathname;
    		var EditMode = false;
    		var NewDataMode = false;
    		var UploadNeeded = false,
    			RemoveNeeded = false;
    		var RemoveStatus;
			var EditableState = false;
    		var jsonPreloaded = [];
    		var FolderDoc = "suratmasuk";
    		<?php
			$hash = hash('sha512', rand());
			$pos = substr(rand(), 0, 1);
			$mnu = $pos . substr($hash, 0, 128 - intval($pos)) . $AppClass->KodeMenu . substr($hash, -1 * intval($pos));
			?>
    		var page_list = '<?php echo  base_url() . "/" . strtolower($controller_name) . "/mnu/" . substr(md5(rand()), 4, 7) . "/salt/" . $mnu ?>';

    		$(".quick-select").on("click", function() {
    			var nilai = $(this).data("value"); // Ambil teks dari tombol
    			$("#Catatan").val(nilai); // Masukkan teks ke textarea
    		});

    		$("#page_form .btn-save").off().on("click", function() {
    			saveData()
    		});
    		$("#page_form .btn-close").off().on("click", function() {
    			reloadPage()
    		});

    		// $(".editable-check[name='chkSatuan_1']").on("click",function() { isCheckAll(); });
    		// $("#chkSatuan_2_All").on("click",function() { 
    		// 	$(".editable-check[name='chkSatuan_1']").prop("checked",$(this).prop("checked"));
    		// });


    		if ($("#page_form .timepicker").get().length > 0) {
    			//Date picker
    			$('#page_form .timepicker').timepicker({
    				showInputs: false,
    				timeFormat: 'HH:mm:ss',
    				showMeridian: false
    			})
    		}

			if($("#page_form .form-control[name='EditDisabled']").val()=="0") EditableState = true;
			datatable = $("#datatable").DataTable({
            	destroy: true, //elakkan dari error initialise
//				orderCellsTop: true,
//		        fixedHeader: true,
				"ordering": false,
			  	"scrollX": true,
			  	"language": {
			  	"paginate": {
				  "previous": "<",
				  "next": ">"
				  }
			  	},

				dom:
					"<'row'<'col-sm-6'B><'col-sm-6'f>>" +
					"<'row'<'col-sm-12'tr>>" +
					"<'row'<'col-sm-4'i><'col-sm-4 text-center'l><'col-sm-4'p>>"
					,
				"buttons": [
					{
						text: '<i class="fas fa-plus"></i>  Add',
						className: 'btn btn-info btn-sm btn-new',
		                enabled: EditableState,
						action: function ( e, dt, node, config ) {
							pleaseWait('Please wait while opening form');
							var param = '0='+escape(page_list);
                            param += "&<?= csrf_token() ?>=<?= csrf_hash() ?>";
							param += '&id='+escape($("#page_form .form-control[name='KodeLama']").val()+"-");
							// param += '&wil='+escape($("#page_form .form-control[name='Wilayah']").val());
							// alert(param)
							var i = 0;
							var url = page_list+"/frx/Add";
//							$("#page_form .selectpicker").each(function() { 
//								i++;
//								url += "/p0"+i+$(this).val();
//							});
////							url += "/kat"+$(this).val()+"/cod";
							$.ajax({
								url: url, 
								type:'POST',
								data:param,
								success:function(response){ 
									Swal.close();
									$("#theModalForm").html("Form Input Detail Permohonan (Mustahiq)"); 
									$(".modalForm .modal-body").html(response); 
									$(".modalForm").modal("show"); 
//									$('.modalForm .selectpicker').selectpicker();

                                    $(".modalForm .select2[name='Kategori']").select2();
                                    $(".modalForm .select2[name='Kabupaten']").select2();
                                    $(".modalForm .select2[name='KategoriPemohon']").select2();
                                    $(".modalForm .select2[name='Realisasi']").select2();

									$(".modalForm .select2[name='Rekomendasi']").select2({
                                        tags: true,  // Menambahkan kemampuan input bebas untuk membuat tag baru
                                        tokenSeparators: [','], // Memisahkan tag menggunakan koma atau spasi
                                        placeholder: 'Pilih/Isikan Pemberi Rekomendasi',
                                        createTag: function(params) {
                                            // Menambahkan tag baru ke dalam dropdown secara otomatis
                                            var term = $.trim(params.term);
                                            return {
                                                id: term,
                                                text: term,
                                                newOption: true  // Menandai bahwa ini adalah opsi baru yang dibuat
                                            };
                                        }
                                    });

									// $(".modalForm .form-option").iCheck();

									$(".modalForm .form-control[name='NIK']").inputmask('9999999999999999');
									// $(".modalForm .form-control[name='NomorKK']").inputmask('9999999999999999');
//									$(".modalForm .form-control[name='RTRW']").inputmask('999/999');
									$(".modalForm .form-control[name='Handphone']").on("keyup",function (e) { 
										this.value = this.value.replace(/[^0-9\.]/g,'');
									});
									// $(".modalForm .form-control[name='RT']").on("keyup",function (e) { 
									// 	this.value = this.value.replace(/[^0-9\.]/g,'');
									// });
									// $(".modalForm .form-control[name='RW']").on("keyup",function (e) { 
									// 	this.value = this.value.replace(/[^0-9\.]/g,'');
									// });
                                    // var input = document.querySelector('#Rekomendasi');
                                    // var tagify = new Tagify(input, {
                                    //     enforceWhitelist: false, // Izinkan input bebas
                                    //     maxTags: 5,              // Maksimal 5 tag
                                    //     delimiter: [',', ' '],   // Karakter pemisah (koma atau spasi)
                                    //     dropdown: {
                                    //         enabled: 0, // Menonaktifkan dropdown
                                    //         maxItems: 5
                                    //     }
                                    // });
									$(".modalForm .text-right").inputmask('currency', {"autoUnmask": true,
						//                'alias': 'numeric',
										'groupSeparator': '.',
										'autoGroup': true,
										'digits': 0,
										'radixPoint': ",",
										'digitsOptional': false,
										'allowMinus': false,
										'prefix': 'Rp. ',
										'placeholder': '',
										rightAlign: true,
										unmaskAsNumber: true
									});


									$('#paramdate5').datetimepicker({
										maxDate: "now",
										format: 'YYYY-MM-DD'
									});
									$('#paramdate6').datetimepicker({
										maxDate: "now",
										format: 'YYYY-MM-DD'
									});

									$(".modalForm .control-save-modal").off().on('click', function() {
										saveDataAdd();
//										mySwal("Sorry","Underconstruction...","warning");
										
									});
						
								}, error: function(jqXHR, textStatus, errorThrown) {  
									Swal.close();
									// Swal.fire({ title: jqXHR.status+" Error", text: "Internal Error in Opening Form.", icon: "error" });
									Swal.fire({ title: jqXHR.status+" Error", text: jqXHR.responseText, icon: "error" });
								}
							});
						}
					},
					{
						text: '<i class="fas fa-upload"></i>  Upload XLS',
						className: 'btn btn-info btn-sm btn-upload d-none',
						action: function ( e, dt, node, config ) {
							//mySwal("Attention","Underconstruction","warning");
							pleaseWait('Please wait while opening form');
							var param = '0='+escape(page_list);
							var i = 0;
							var url = page_list+"/frx/Upload";
//							$("#page_form .selectpicker").each(function() { 
//								i++;
//								url += "/p0"+i+$(this).val();
//							});
////							url += "/kat"+$(this).val()+"/cod";
							$.ajax({
								url: url, 
								type:'POST',
								data:param,
								success:function(response){
									Swal.close();
									$("#theModalForm").html("Form Upload Mustahiq"); 
									$(".modalForm .modal-body").html(response); 
									$(".modalForm").modal("show"); 
									$('.modal-dialog').css('max-width','96%');  
									datatable2 = $("#datamustahiq").DataTable({
										destroy: true, //elakkan dari error initialise
						//				orderCellsTop: true,
						//		        fixedHeader: true,
										"ordering": false,
										"scrollX": true,
										"language": {
										"paginate": {
										  "previous": "<",
										  "next": ">"
										  }
										},
										initComplete: function () {
											$.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
										}
									});
									setTimeout(function() {
									   $($.fn.dataTable.tables(true)).DataTable()
										  .columns.adjust();
									},500);


									$(".modalForm .modal-body .file-input").on("change",function() {
//										if($("#theModalForm .form-control[name='TransaksiClosed']").val()=="0") {
//											$("#alert_pad").hide();
											datatable2.clear().draw();
											$(".control-save").prop("disabled",true);	
											if($(this).val()!="") 
												$('.control-preview').prop("disabled",false);
											else {
												$('.control-preview').prop("disabled",true);
											}
//										}
									});
									$(".modalForm .modal-body .control-preview").on("click",function() { 
										var formData = new FormData($('#modal_form').get(0));
										Swal.fire({
											title: 'Generating Preview',
											html: 'Please wait while data is being processed',
											didOpen: () => {
												Swal.showLoading();
												datatable2.clear().draw();
												var isValid = true;
												$.ajax({
													url:base_url_class+"preview_xls",

													method:"POST",
													data:formData,
													processData:false,
													contentType:false,
													cache:false,
													success:function(val){ // alert(val)
														val = JSON.parse(val);
														var i = 0;
														$.each(val,function(idx,data){ 
						//									if(i>0) {
																if(data.Valid=="1") {
																	datatable2.row.add([
																		data.Seq+'.', 
																		data.Nama+(data.Nama_mst!=data.Nama ? '<br><span class="text-red">('+data.Nama_mst+')</span>' : ''), 
																		data.NIK, 
																		data.NomorKK, 
																		data.Alamat+(data.Alamat_mst!=data.Alamat ? '<br><span class="text-red">('+data.Alamat_mst+')</span>' : ''),  
																		data.RT+'/'+data.RW, 
																		data.DesaAlias, 
																		data.Handphone, 
																		data.JenisBantuan, 
																		formatRupiah(data.Nominal,0), 
																		data.Keterangan 
																	]).draw(false);
																} else if(data.Valid=="2") {
																	var rowNode = datatable2.row.add([
																		data.Seq+'.', 
																		data.Nama, 
																		data.NIK, 
																		data.NomorKK, 
																		data.Alamat, 
																		data.RT+'/'+data.RW, 
																		data.DesaAlias, 
																		data.Handphone, 
																		data.JenisBantuan, 
																		formatRupiah(data.Nominal,0), 
																		data.Keterangan, 
																	]).draw().node();
																	$(rowNode).addClass('bg-warning text-red');
																} else if(data.Valid=="3") {
																	var rowNode = datatable2.row.add([
																		'<div class="icheck-primary d-inline"><input id="chkMaster" name="chkMaster" class="editable-check" type="checkbox" value=""><label for="chkMaster"></label></div>', 
																		data.Nama, 
																		data.NIK, 
																		data.NomorKK, 
																		data.Alamat, 
																		data.RT+'/'+data.RW, 
																		data.DesaAlias, 
																		data.Handphone, 
																		data.JenisBantuan, 
																		formatRupiah(data.Nominal,0), 
																		'<span class="text-red">Belum ada di master</span>', 
																	]).draw().node();
																	// $(rowNode).addClass('text-red');
																} else {
																	isValid = false;
																	datatable2.row.add([
																		'<span class="text-red">'+data.Seq+'</span>', 
																		'<span class="text-red">'+data.Nama+'</span>', 
																		'<span class="text-red">'+data.NIK+'</span>', 
																		'<span class="text-red">'+data.NomorKK+'</span>', 
																		'<span class="text-red">'+data.Alamat+'</span>', 
																		'<span class="text-red">'+data.RT+'/'+data.RW+'</span>', 
																		'<span class="text-red">'+data.DesaAlias+'</span>', 
																		'<span class="text-red">'+data.Handphone+'</span>', 
																		'<span class="text-red">'+data.JenisBantuan+'</span>', 
																		'<span class="text-red">'+formatRupiah(data.Nominal,0)+'</span>', 
																		'<span style="min-width:20vw" class="text-red">'+data.Keterangan+'</span>', 
																	]).draw(false);
																}
						//									}
															i++;
														});
														if(isValid) { // && $("#page_form .form-control[name='TransaksiClosed']").val()=="0") {
															$(".control-save-modal").prop("disabled",false);	
//															$("#alert_pad").hide();
														} else {
															$(".control-save-modal").prop("disabled",true);	
//															$("#alert_pad").show();
														}
														Swal.close(); 
													}, 
													error: function(jqXHR, textStatus, errorThrown) {  
														Swal.close();
														Swal.fire({ title: "Ooops...", html: jqXHR.responseText, icon: "error" });
														// Swal.fire({ title: "Ooops...", html: "Periksa lagi format kolom file excel Anda.<br />Jika belum jelas hubungi Call Center BAZNAS.", icon: "error" });
													}
												});
											}
										});
									});

									$(".modalForm .control-save-modal").on('click', function() {
										// saveDataUpload();
										var formData = new FormData($('#modal_form').get(0));
										formData.append('KodeLama', escape($("#page_form .form-control[name='KodeLama']").val()));
										Swal.fire({
											title: 'Upload Data',
											html: 'Please wait while data is being uploaded',
											didOpen: () => {
												Swal.showLoading();
												//datatable.clear().draw();
												//var isValid = true;
												$.ajax({
													url:base_url_class+"upload_xls",
													method:"POST",
													data:formData,
													processData:false,
													contentType:false,
													cache:false,
													success:function(response){ //alert(response)
														if(response.toLowerCase().indexOf("session habis")>=0) {
															Swal.close(); 
															Swal.fire({ title: "Session Error", text: response,icon: "error",})
																.then((result) => {
																	if (result.isConfirmed) { window.location.reload(); } 
																});
														} else { 
															arResp = response.split("###");
															if(arResp[0]=="0") { 
																if(arResp[2].indexOf("<!--##-->")>0) {
																	arResponse = arResp[2].split("<!--##-->");
																	for(var i=0;i<arResponse.length;i++) {
																		arVal = arResponse[i].split("@@@");
																		$("#page_form .form-control[name='"+arVal[0]+"']").val(arVal[1]);	
																	}
																	setTimeout(function() {
																		Swal.close(); 
																		Swal.fire({ title: "Success", html: arResp[1],icon: "success",})
																			.then((result) => { 				
																				if (result.isConfirmed) { 
																					pleaseWait(); 
																					var url = page_list+'/frm';
																					url += "/cod"+$("#page_form input.form-control[name='KodeLama']").val();
																					window.location = url;
																				} 
																		});
																	},1000);
																}
															} else {
																Swal.close(); 
																Swal.fire({ title: "Error", text: arResp[1], icon: "error" });
															}
														}
													}, 
													error: function(jqXHR, textStatus, errorThrown) {  
														Swal.close();
														Swal.fire({ title: "Ooops...", html: "Periksa lagi format kolom file excel Anda.<br />Jika belum jelas hubungi Call Center BAZNAS.", icon: "error" });
													}
												});
											}
										});										
									});
						
								}, error: function(jqXHR, textStatus, errorThrown) {  
									Swal.close();
									Swal.fire({ title: jqXHR.status+" Error", text: "Internal Error in Opening Form.", icon: "error" });
								}
							});
						}
					}
				],
				initComplete: function () {
					$.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
				}
			});
			$("#tab-2-tab").on("shown.bs.tab",function(e) { 
			   $($.fn.dataTable.tables(true)).DataTable()
				  .columns.adjust();
			});

    		//Date range picker
    		$('#paramdate').datetimepicker({
    			maxDate: "now",
    			format: 'YYYY-MM-DD'
    		});

    		$('#paramdate2').datetimepicker({
    			maxDate: "now",
    			format: 'YYYY-MM-DD'
    		});

    		$('#paramdate3').datetimepicker({

    			format: 'YYYY-MM-DD'
    		});


    		$('.inline-editor').summernote({
    			//				dialogsInBody: true,
    			height: 150,
    			placeholder: "Isikan Isi/Ringkasan",
    			toolbar: [
    				// [groupName, [list of button]]
    				['style', ['bold', 'italic', 'underline', 'clear']],
    				['font', ['strikethrough', 'superscript', 'subscript']],
    				['fontsize', ['fontsize']],
    				['color', ['color']],
    				['para', ['ul', 'ol', 'paragraph']],
    				['height', ['height']]
    			]
    		});

    		$(".control-add").on("click", function(e) {
    			e.preventDefault();
    			var sHTML = '<div class="fileinputt fileinput-new input-group" style="margin:15px 0 10px" data-provides="fileinput">';
    			sHTML += '                <div class="form-control" data-trigger="fileinput">';
    			sHTML += '          <i class="fa fa-file fileinput-exists"></i>';
    			sHTML += '          <span class="fileinput-filename"></span>';
    			sHTML += '      </div>';
    			sHTML += '      <span class="input-group-addon btn btn-primary btn-file"> ';
    			sHTML += '          <span class="fileinput-new">Select file</span>';
    			sHTML += '      <span class="fileinput-exists">Change</span>';
    			sHTML += '      <input type="file" name="DokumenPath" class="file-input">';
    			sHTML += '      </span>';
    			sHTML += '      <a href="#" class="input-group-addon btn btn-danger fileinput-exists" data-dismiss="fileinput">Remove</a> ';
    			//                sHTML += '      <a href="#" class="input-group-addon btn btn-danger control-remove" style="margin-left:1px;">-</a>';
    			sHTML += '      <input type="hidden" name="FileOri" class="form-control" value="">';
    			sHTML += '      </div>';
    			$(".doc-pad").append(sHTML);
    			$(".doc-pad .control-remove").off().on("click", function(e) {
    				e.preventDefault();
    				$(this).closest(".fileinputt").remove();
    			});
    		});
    		$(".doc-pad .control-remove").on("click", function(e) {
    			e.preventDefault();
    			$(this).closest(".fileinputt").remove();
    		});

    		if ($("input[class='preloaded']").get().length > 0) {
    			jsonPreloaded = [];
    			$("input[class='preloaded']").each(function() {

    				var id = $(this).attr("id");
    				var src = $(this).val();

    				item = {}
    				item["id"] = id;
    				item["src"] = src;

    				jsonPreloaded.push(item);
    			});
    		}

    		$('.input-images').imageUploader({
    			preloaded: jsonPreloaded,
    			imagesInputName: 'photos',
    			preloadedInputName: 'old'
    		});

    		$(".control-back").on("click", function(e) {
    			e.preventDefault();
    			pleaseWait();
    			window.location = page_list;
    		})
    		$(".control-edit").on("click", function(e) {
    			e.preventDefault();
    			EditMode = true;
    			toggleEdit();
    		})
    		$(".control-close").on("click", function() {
    			if ($("#page_form .form-control[name='KodeLama']").val() != "" &&
    				EditMode) {
    				EditMode = false;
    				toggleEdit();
    			} else {
    				pleaseWait();
    				window.location = page_list;
    			}
    		})

    		$(".control-delete").on("click", function(e) {
    			e.preventDefault();
    			var btn = $(this);
    			Swal.fire({
    				title: "<span style='color:#dc3545'>Anda yakin?</span>",
    				text: "Anda akan menghapus data ini",
    				icon: "question",
    				confirmButtonText: "Ya",
    				confirmButtonColor: "#dc3545",
    				cancelButtonText: "Tidak",
    				showCancelButton: true,
    			}).then((result) => {
    				if (result.isConfirmed) {
    					Swal.showLoading();
    					delData($("#page_form .form-control[name='KodeLama']").val());
    				}
    			});

    		});
    		$(".control-save").off().on("click", function(e) {
    			e.preventDefault();
    			saveData();
    		});

			$("#datatable").on("click","a.control-view", function(e) { 
				e.preventDefault();
				var btn = $(this);
				pleaseWait('Please wait while opening form');
				var param = '0='+escape(page_list);
				param += "&<?= csrf_token() ?>=<?= csrf_hash() ?>";
				param += '&id='+escape($(this).data("idx"));
				// param += '&wil='+escape($("#page_form .form-control[name='Wilayah']").val());
				var i = 0;
				var url = page_list+"/frx/Add";
				$.ajax({
					url: url, 
					type:'POST',
					data:param,
					success:function(response){ 
						Swal.close();
						$("#theModalForm").html("Form Update Detail Permohonan (Mustahiq)");

						$(".modalForm .modal-body").html(response); 
						$(".modalForm").modal("show"); 
//									$('.modalForm .selectpicker').selectpicker();

						$(".modalForm .select2[name='Kategori']").select2();
						$(".modalForm .select2[name='Kabupaten']").select2();
						$(".modalForm .select2[name='KategoriPemohon']").select2();
						$(".modalForm .select2[name='Realisasi']").select2();

						$(".modalForm .select2[name='Rekomendasi']").select2({
							tags: true,  // Menambahkan kemampuan input bebas untuk membuat tag baru
							tokenSeparators: [','], // Memisahkan tag menggunakan koma atau spasi
							placeholder: 'Pilih/Isikan Pemberi Rekomendasi',
							createTag: function(params) {
								// Menambahkan tag baru ke dalam dropdown secara otomatis
								var term = $.trim(params.term);
								return {
									id: term,
									text: term,
									newOption: true  // Menandai bahwa ini adalah opsi baru yang dibuat
								};
							}
						});

						// $(".modalForm .form-option").iCheck();

						$(".modalForm .form-control[name='NIK']").inputmask('9999999999999999');
						// $(".modalForm .form-control[name='NomorKK']").inputmask('9999999999999999');
//									$(".modalForm .form-control[name='RTRW']").inputmask('999/999');
						$(".modalForm .form-control[name='Handphone']").on("keyup",function (e) { 
							this.value = this.value.replace(/[^0-9\.]/g,'');
						});
						// $(".modalForm .form-control[name='RT']").on("keyup",function (e) { 
						// 	this.value = this.value.replace(/[^0-9\.]/g,'');
						// });
						// $(".modalForm .form-control[name='RW']").on("keyup",function (e) { 
						// 	this.value = this.value.replace(/[^0-9\.]/g,'');
						// });
						// var input = document.querySelector('#Rekomendasi');
						// var tagify = new Tagify(input, {
						//     enforceWhitelist: false, // Izinkan input bebas
						//     maxTags: 5,              // Maksimal 5 tag
						//     delimiter: [',', ' '],   // Karakter pemisah (koma atau spasi)
						//     dropdown: {
						//         enabled: 0, // Menonaktifkan dropdown
						//         maxItems: 5
						//     }
						// });
						$(".modalForm .text-right").inputmask('currency', {"autoUnmask": true,
			//                'alias': 'numeric',
							'groupSeparator': '.',
							'autoGroup': true,
							'digits': 0,
							'radixPoint': ",",
							'digitsOptional': false,
							'allowMinus': false,
							'prefix': 'Rp. ',
							'placeholder': '',
							rightAlign: true,
							unmaskAsNumber: true
						});


						$('#paramdate5').datetimepicker({
							maxDate: "now",
							format: 'YYYY-MM-DD'
						});
						$('#paramdate6').datetimepicker({
							maxDate: "now",
							format: 'YYYY-MM-DD'
						});						



						$(".modalForm .control-save-modal").off().on('click', function() {
							saveDataAdd();
							//mySwal("Sorry","Underconstruction...","warning");
						});
			
					}, error: function(jqXHR, textStatus, errorThrown) {  
						Swal.close();
						
						Swal.fire({ title: jqXHR.status+" Error", text: "Internal Error in Opening Form.", icon: "error" });
					}
				});
			});
			$("#datatable").on("click","a.control-del", function(e) { 
				e.preventDefault();
				var btn = $(this);
				Swal.fire({
					  title: "<span style='color:#dc3545'>Anda yakin?</span>",
					  text: "Anda akan menghapus data mustahiq ini",
					  icon: "question",
					  confirmButtonText: "Ya",
					  confirmButtonColor: "#dc3545",
					  cancelButtonText: "Tidak",
					  showCancelButton: true,
				}).then((result) => { 
					if (result.isConfirmed) {
//						Swal.showLoading();
//						mySwal("Sorry","Underconstruction...","warning");
						delData($(this).data("idx")); 
						
					} 
				});
			});
			
    		function delData(kode) {
    			var param = '0=' + escape(page_href) + "&1=";
    			if (kode) {
    				param += escape(kode) + '@@@';
    			} else {
    				$("#table-data .cb-data:checked").each(function() {
    					param += escape($(this).val()) + '@@@';
    				});
    			}
    			if (param != '') {
    				$.ajax({
    					type: "POST",
    					url: base_url_class + "del_data",
    					data: param,
    					success: function(msg) {
    						if (msg.toLowerCase().indexOf("session habis") >= 0) {
    							Swal.fire({
    									title: "Session Error",
    									text: msg,
    									icon: "error",
    								})
    								.then((result) => {
    									if (result.isConfirmed) {
    										window.location.reload();
    									}
    								});
    						} else if (msg.indexOf('@@@') > 0) {
    							arMsg = msg.split('@@@');
    							if (parseInt(arMsg[0]) == 0) {
    								//									reloadPage();
    								//									pleaseWait();
    								//									window.location = page_list;
    								Swal.fire({
    										title: "Success",
    										text: "Data berhasil dihapus",
    										icon: "success",
    									})
    									.then((result) => {
    										if (result.isConfirmed) {
    											pleaseWait();
    											// window.location = page_list; 
												window.location.reload();
    										}
    									});
    							} else {
    								Swal.fire({
    										title: "Attention",
    										text: arMsg[1],
    										icon: "warning",
    									})
    									.then((result) => {
    										if (result.isConfirmed) {
    											pleaseWait();
    											// window.location = page_list;
												window.location.reload();												
    										}
    									});
    							}
    						} else {
    							mySwal("Error", msg + ".\nMohon coba lagi...", "error");
    						}
    					},
    					error: function() {
    						mySwal("Attention", "Demi stabilitas data, saat ini tidak diperkenankan untuk penghapusan data lewat aplikasi.\nSilahkan hubungi web administrator.", "warning");
    					}
    				});
    			}
    		}

    		function saveData() {
    			var param = '0=' + escape(page_href) + "&",
    				parammenus = '';
    			NewDataMode = ($("#page_form .form-control[name='KodeLama']").val() == "") ? true : false;
    			if (param != '') {
    				$("#page_form input.form-control[type='hidden']").each(function() {
    					param += $(this).attr("name") + "=" + escape($(this).val()) + "&";
    				});
    			}
    			if (param != '') {
    				$("#page_form input.form-control[type!='radio'][type!='checkbox']").each(function() { // text, date
    					if ($.trim($(this).val()) == '' && $(this).attr("required") == "required") {
    						mySwal("Validation", 'Isikan ' + $(this).attr("placeholder"), "warning");
    						$(this).focus();
    						param = '';
    						return false;
    					} else
    						param += $(this).attr("name") + "=" + escape($(this).val()) + "&";
    				});
    			}
    			if (param != '') {
    				$("#page_form textarea.form-control").each(function() {
    					if ($.trim($(this).val()) == '' && $(this).attr("required") == "required") {
    						mySwal("Validation", 'Isikan ' + $(this).attr("placeholder"), "warning");
    						$(this).focus();
    						param = '';
    						return false;
    					} else
    						param += $(this).attr("name") + "=" + escape($(this).val()) + "&";
    				});
    			}
    			if (param != '') {
    				$("#page_form select.form-control").each(function() {
    					param += $(this).attr("name") + "=" + escape($(this).val()) + "&";
    				});
    			}
    			if (param != '') {
    				$("#page_form input.form-control[type='radio']").each(function() {
    					if ($("#page_form .form-control[name='" + $(this).attr("name") + "']:checked").get().length == 0 && $(this).attr("required") == "required") {
    						mySwal("Validation", 'Pilih ' + $(this).attr("placeholder"), "warning");
    						param = '';
    						return false;
    					} else
    						param += $(this).attr("name") + "=" + escape($("#page_form .form-control[name='" + $(this).attr("name") + "']:checked").val()) + "&";
    				});
    			}
    			if (param != '') {
    				$("#page_form input.form-control[type='checkbox']").each(function() {
    					if ($(this).prop("checked")) {
    						param += $(this).attr("name") + "=1&";
    					} else {
    						param += $(this).attr("name") + "=2&";
    					}
    				});
    			}
    			if (param != '') {
    				$("#page_form .inline-editor").each(function() {
    					param += $(this).attr("data-name") + "=" + escape($.trim($(this).summernote("code"))) + "&";
    				});
    			}

    			// 				if(param!='') {
    			// 					parampersonels += '&personels=';
    			// //					$("#page_form .editable-check[name='chkPersonel']:checked").each(function() {
    			// //					$('#datatable').DataTable().rows().iterator('row', function(context, index){
    			// 					$('#datatable').DataTable().rows().nodes().to$().each(function () {
    			// 						var node = $(this); 
    			// 						//node.context is element of tr generated by jQuery DataTables.
    			// 						if(node.find(".editable-check[name='chkPersonel']:checked").get().length>0) {
    			// 							var thisVal = node.find(".editable-check[name='chkPersonel']:checked").val();
    			// //							if($(this).prop("checked")) {
    			// 								parampersonels += escape(thisVal);
    			// 								if(node.find(".editable-check[name^='optKomandan']").prop("checked")) {
    			// 									parampersonels += "@@@1";
    			// 								} else {
    			// 									parampersonels += "@@@0";
    			// 								}
    			// 								parampersonels += "###";
    			// //							}
    			// 						}
    			// 					});

    			// 					if(parampersonels=='&personels=') {
    			// 						mySwal("Validation","Pilih Personel!","warning");
    			// 						param = '';	
    			// 					} else if (parampersonels=='') {
    			// 						param = '';
    			// 					} else {
    			// 						param+=parampersonels;
    			// 					}
    			// 				}

    			//				        alert(param); 
    			//				param='';
    			if (param != '') {
    				Swal.fire({
    					title: "Anda yakin?",
    					html: "Surat akan diajukan ke atasan untuk ditindaklanjuti. Pastikan isinya sudah sesuai.<br>Lanjutkan?",
    					icon: "question",
    					confirmButtonText: "Ya",
    					cancelButtonText: "Tidak",
    					showCancelButton: true,
    				}).then((result) => {
    					if (result.isConfirmed) {
    						Swal.close();
    						Swal.fire({
    							title: 'Saving Process',
    							html: 'Please wait while data is being processed',
    							//						  timer: 2000,
    							//						  timerProgressBar: true,
    							didOpen: () => {
    								Swal.showLoading();
    								$.ajax({
    									type: "POST",
    									url: base_url_class + "save_data",
    									data: param,
    									success: function(response) { //alert(response);
    										if (response.toLowerCase().indexOf("session habis") >= 0) {
    											Swal.close();
    											Swal.fire({
    													title: "Session Error",
    													text: response,
    													icon: "error",
    												})
    												.then((result) => {
    													if (result.isConfirmed) {
    														window.location.reload();
    													}
    												});
    										} else {
    											arResp = response.split("###");
    											if (arResp[0] == "0") {
    												if (arResp[2].indexOf("<!--##-->") > 0) {
    													arResponse = arResp[2].split("<!--##-->");
    													for (var i = 0; i < arResponse.length; i++) {
    														arVal = arResponse[i].split("@@@");
    														$("#page_form .form-control[name='" + arVal[0] + "']").val(arVal[1]);
    													}
    													setTimeout(function() {

    														$("#page_form .fileinputt").each(function() {
    															if ($(this).find(".file-input")[0].files.length !== 0) {
    																UploadNeeded = true;
    																//return false;
    															}
    															if ($(this).find(".form-control[name^='FileOri']").val() != "" &&
    																$(this).find('.fileinput-filename').html() == "") {
    																RemoveNeeded = true;
    																//return false;
    															}
    														});
    														if (UploadNeeded) {
    															uploadFile();
    														} else if (RemoveNeeded) {
    															removeFile();
    															//} else {


    															// Get the input file
    															// $inputImages = $("#page_form").find('input[name^="images"]');
    															// if (!$inputImages.length) {
    															// 	$inputImages = $("#page_form").find('input[name^="photos"]')
    															// }
    															// $inputPreloaded = $("#page_form").find('input[name^="old"]');

    															// $("input[class='preloaded']").each(function() {
    															// 	var src = $(this).val(),
    															// 		id = $(this).attr("id"),
    															// 		isExists = false;
    															// 	$("#page_form").find('input[name^="old"]').each(function() {
    															// 		if ($(this).parent().find("img").attr("src") == src) {
    															// 			isExists = true;
    															// 			return false;
    															// 		}
    															// 	});
    															// 	if (!isExists) delDataFoto(id, src);
    															// });
    															// var $startJ = -1;
    															// $("#page_form").find('input[name^="old"]').each(function() {
    															// 	$startJ = Math.max($(this).val(), $startJ);
    															// });
    															// $startJ++;
    															// if ($('.input-images').find("input").prop('files').length > 0) {
    															// 	for (var j = 0; j < $('.input-images').find("input").prop('files').length; j++) {
    															// 		if ((j + 1) < $('.input-images').find("input").prop('files').length)
    															// 			saveDataFoto("", $('.input-images').find("input").get(0).files[j], j + $startJ);
    															// 		else
    															// 			saveDataFoto(arResp[1], $('.input-images').find("input").get(0).files[j], j + $startJ);
    															// 	};

    														} else {
    															Swal.close();
    															Swal.fire({
    																	title: "Success",
    																	text: arResp[1],
    																	icon: "success",
    																})
    																.then((result) => {
    																	if (result.isConfirmed) {
    																		pleaseWait();
    																		if ($("#page_form .form-control[name='KodeLama']").val() == "")
    																			window.location = page_list;
    																		else
    																			window.location = page_list;
    																	}
    																});
    														}



    														//}
    													}, 100);
    												}
    											} else {
    												Swal.close();
    												Swal.fire({
    													title: "Error",
    													text: arResp[1],
    													icon: "error"
    												});
    											}
    										}
    									},
    									error: function(jqXHR, textStatus, errorThrown) {
    										Swal.close();
    										Swal.fire({
    											title: jqXHR.status + " Error",
    											text: "Internal Error in Saving Data.",
    											icon: "error"
    										});
    									}
    								});
    							}
    						});
    					}
    				});
    			}
    		}

			function saveDataAdd() { 
				var param = '0='+escape(page_href)+"&ext=Add&", parammenus = '';
				if(param!='') {
					$("#page_form input.form-control[type='hidden']").each(function() {
							param += $(this).attr("name")+"="+escape($(this).val())+"&";
					});
				}
				if(param!='') {
					$(".modalForm input.form-control[type!='radio'][type!='checkbox']").each(function() { // text, date
						if($.trim($(this).val())=='' && $(this).attr("required")=="required") {
							mySwal("Validation",'Isikan '+$(this).attr("title"),"warning");
							$(this).focus();
							param='';
							return false;
						} else
							param += $(this).attr("name")+"="+escape($(this).val())+"&";
					});
				}
				if(param!='') {
					$(".modalForm textarea.form-control").each(function() { 
						if($.trim($(this).val())=='' && $(this).attr("required")=="required") {
							mySwal("Validation",'Isikan '+$(this).attr("title"),"warning");
							$(this).focus();
							param='';
							return false;
						} else
							param += $(this).attr("name")+"="+escape($(this).val())+"&";
					});
				}
				if(param!='') {
					$(".modalForm select.form-control").each(function() {
						if($.trim($(this).val())=='' && $(this).attr("required")=="required") {
							mySwal("Validation",'Pilih '+$(this).attr("title"),"warning");
							param='';
							return false;
						} else
							param += $(this).attr("name")+"="+escape($(this).val())+"&";
					});
				}
				if(param!='') {
					$(".modalForm input.form-option[type='radio']").each(function() {
						if($(".modalForm .form-option[name='"+$(this).attr("name")+"']:checked").get().length==0 
							&& $(this).attr("required")=="required") {
							mySwal("Validation",'Pilih '+$(this).attr("title"),"warning");
							param='';
							return false;
						} else
							param += $(this).attr("name")+"="+escape($(".modalForm .form-option[name='"+$(this).attr("name")+"']:checked").val())+"&";
					});
				}
				if(param!='') {
					$(".modalForm input.form-option[type='checkbox']").each(function() {
						if($(this).prop("checked")) {
							param += $(this).attr("name")+"=1&";
						} else {
							param += $(this).attr("name")+"=2&";
						}
					});
				}
				if(param!='') {	// special check
					$(".modalForm input.form-control[name='NIK'],.modalForm input.form-control[name='NomorKK']").each(function() {
						if($(this).val().indexOf("_")>=0) {
							mySwal("Validation",'Cek lagi '+$(this).attr("title"),"warning");
							param='';
							return false;
						}
					});
				}

//				param='';
				if(param!='') { 
					Swal.fire({
						  title: "Anda yakin?",
						  text: "Anda akan menyimpan perubahan data ini",
						  icon: "question",
						  confirmButtonText: "Ya",
						  cancelButtonText: "Tidak",
						  showCancelButton: true,
					}).then((result) => { 
						if (result.isConfirmed) {
//							mySwal("Sorry","Underconstruction...","warning");
							Swal.close();
							Swal.fire({
							  title: 'Saving Process',
							  html: 'Please wait while data is being processed',
	//						  timer: 2000,
	//						  timerProgressBar: true,
							  didOpen: () => {
								Swal.showLoading();
								$.ajax({ 
									type: "POST", 
									url: base_url_class+"save_data_ext", 
									data: param, 
									success: function(response){ 		//	alert(response);
										if(response.toLowerCase().indexOf("session habis")>=0) {
											Swal.close(); 
											Swal.fire({ title: "Session Error", text: response,icon: "error",})
												.then((result) => {
													if (result.isConfirmed) { window.location.reload(); } 
												});
										} else { 
											arResp = response.split("###");
											if(arResp[0]=="0") { 
												if(arResp[2].indexOf("<!--##-->")>0) {
													arResponse = arResp[2].split("<!--##-->");
													for(var i=0;i<arResponse.length;i++) {
														arVal = arResponse[i].split("@@@");
														$(".modalForm .form-control[name='"+arVal[0]+"']").val(arVal[1]);	
													}

													Swal.close(); 
													Swal.fire({ title: "Success", text: arResp[1],icon: "success",})
														.then((result) => { 				
															if (result.isConfirmed) { 
																pleaseWait(); 
																//window.location.reload();
																var url = page_href;
																// if(url.indexOf("/p0102")<0) 
																// 	url += "/p0102";
				
																if(url.indexOf("/cod")<0) {
																	url += "/cod"+$("#page_form .form-control[name='KodeLama']").val();	
																	//window.location = url;
																} //else window.location.reload(); 
																window.location = url;
															} 
													});
												}
											} else {
												Swal.close(); 
												Swal.fire({ title: "Error", text: arResp[1], icon: "error" });
											}
										}
									}, error: function(jqXHR, textStatus, errorThrown) {  
										Swal.close();
										Swal.fire({ title: jqXHR.status+" Error", text: "Internal Error in Saving Data.", icon: "error" });
									}
								});
							  }
							});				


						} 
					});
				}
			}



    		function pleaseWait() {
    			Swal.close();
    			Swal.fire({
    				title: 'Please wait',
    				html: 'Please wait while reload the page',
    				didOpen: () => {
    					Swal.showLoading()
    				},
    			})

    		}

    		function mySwal(title, text, icon) {
    			Swal.close();
    			Swal.fire({
    				title: title,
    				text: text,
    				icon: icon
    			});
    		}

    		function substrLeft(str, n) {
    			if (n <= 0)
    				return "";
    			else if (n > String(str).length)
    				return str;
    			else
    				return String(str).substring(0, n);
    		}

    		function substrRight(str, n) {
    			if (n <= 0)
    				return "";
    			else if (n > String(str).length)
    				return str;
    			else {
    				var iLen = String(str).length;
    				return String(str).substring(iLen, iLen - n);
    			}
    		}

    		function printData(kode) {
    			$("#GenForm input[name='HRef']").val(escape($(location).attr('href')));
    			$("#GenForm input[name='Doc']").val("");
    			$("#GenForm input[name='Periode']").val($("#Periode").val());
    			$("#GenForm input[name='Kode']").val(kode);
    			$("#GenForm input[name='Key']").val($("#Opsi").val());
    			$("#GenForm").attr("target", "_blank")
    				.attr("action", base_url_class + "print_doc")
    				.submit();
    		}


    		function clearChar(str, chr) {
    			while (str.indexOf(chr) >= 0)
    				str = str.replace(chr, "");
    			return str;
    		}
    		//			// Input New Mode
    		//			if($("#page_form .form-control[name='KodeLama']").val()=="") { 
    		//				EditMode = true;
    		//				toggleEdit();
    		//			}

    	});
    </script>