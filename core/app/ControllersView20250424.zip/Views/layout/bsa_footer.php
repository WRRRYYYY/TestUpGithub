

  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong class="text-success"><!--Copyright--> &copy; <?php echo date("Y") ?> <a href="<?php echo base_url() ?>" class="text-success"><?php echo $NamaInstitusi ?></a>.</strong>
    <!--All rights reserved.-->
    <div class="float-right d-none d-sm-inline-block"> <strong class="text-success"><!--Copyright--> Developed by<a href="https://berliansolusi.co.id/" class="text-success"> Berlian Solusi </a></strong>
      <b>Version</b> 1.0.0
    </div>
  </footer>