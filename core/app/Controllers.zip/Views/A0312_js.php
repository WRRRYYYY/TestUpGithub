	<script src="<?php echo base_url() ?>/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
  	<!-- bootstrap time picker -->
	<script src="<?php echo base_url() ?>/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <!-- DataTables -->
    <script src="<?php echo base_url() ?>/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url() ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url() ?>/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url() ?>/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.8/js/dataTables.fixedHeader.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			var	base_url_class = "<?php echo $base_url_class  ?>", 
				base_url = "<?php echo base_url()  ?>", 
				default_main_segmen = "<?php echo $default_main_content_type  ?>", 
				page_href = window.location.pathname;

			<?php 
				$hash = hash('sha512',rand());
				$pos = substr(rand(),0,1); 
				// $mnu = $pos . substr($hash,0,128-intval($pos)) . $AppClass->KodeMenu . substr($hash,-1*intval($pos));
				$mnu = $pos . substr($hash,0,128-intval($pos)) . "080301" . substr($hash,-1*intval($pos));
			?>
			var page_list = '<?php echo  base_url() . "/". strtolower($controller_name)."/mnu/" . substr(md5(rand()),4,7) . "/salt/" . $mnu; ?>';
			var page_form = '<?php echo  base_url() . "/". strtolower($controller_name)."/mnu/" . substr(md5(rand()),4,7) . "/salt/" . $mnu . "/frm/"; ?>';

			// ##################################################################
			var buttonCommon = {
				exportOptions: {
					format: {
						body: function ( data, row, column, node ) {
							// Strip $ from salary column to make it numeric
							return column < 3 ?	// kolom pertama
								"\0" + data.replace( /(<([^>]+)>)/ig, '') :
								data.replace( /[.,]/g, '' );
						}
					}
				}
			};
			// ##################################################################
			
			datatable = $("#datatable").DataTable({
            	destroy: true, //elakkan dari error initialise
//				orderCellsTop: true,
//		        fixedHeader: true,
				"ordering": false,
				// order: [[1, 'desc']],
				"scrollX": true,
				"language": {
				"paginate": {
					"previous": "<",
					"next": ">"
					}
				},
					"pageLength": 10
			});


			// Inisialisasi popover
			$('[data-toggle="popover"]').popover();


//			$(".control-view").on("click",function(e) { 
//				e.preventDefault();
//				var code = $(this).attr("href");
//				openForm(code);
//			});

			$(".select2").select2({
//				placeholder: this.attr("title")	
			});

			$("#card-header .control-new").on("click",function(e) {
				window.location = page_form;
			});

			$("#card-header .control-reload").on("click",function(e) { 
//				window.location.reload();
				// $(".list-matkul").show("slow");
				pleaseWait('Please wait while opening data list');
				var i = 0;
				var url = page_list+"/def";
				url += "/per"+$("#Periode").val();
//				url += "/kat"+$("#Bulan").val();
				window.location = url;
			});
//			$(".control-delete").on("click", function(e) {
			$("#datatable").on("click","a.control-delete", function(e) { 
				e.preventDefault();
				var btn = $(this);
				Swal.fire({
					  title: "<span style='color:#dc3545'>Anda yakin?</span>",
					  text: "Anda akan menghapus data ini",
					  icon: "question",
					  confirmButtonText: "Ya",
					  confirmButtonColor: "#dc3545",
					  cancelButtonText: "Tidak",
					  showCancelButton: true,
				}).then((result) => { 
					if (result.isConfirmed) {
						Swal.showLoading();
						delData(btn.attr("href")); 
					} 
				});

			});

			function delData(kode)	{ 
				var param = '0='+escape(page_href)+"&1=";
				if(kode) {
					param += escape(kode)+'@@@';
				} else {
					$("#datatable .cb-data:checked").each(function() {
						param += escape($(this).val())+'@@@';
					});
				}
				if(param!='') { 
					$.ajax({ 
						type: "POST", 
						url: base_url_class+"del_data", 
						data: param, 
						success: function(msg){ 
							if(msg.toLowerCase().indexOf("session habis")>=0) {
								Swal.fire({ title: "Session Error", text: msg,icon: "error",})
									.then((result) => {
										if (result.isConfirmed) { window.location.reload(); } 
									});
							} else if(msg.indexOf('@@@')>0) {
								arMsg = msg.split('@@@');
								if(parseInt(arMsg[0])==0)	{
//									reloadPage();
//									pleaseWait();
//									window.location = page_list;
									Swal.fire({ title: "Success", text: "Data berhasil dihapus",icon: "success",})
										.then((result) => {
											if (result.isConfirmed) { 
												pleaseWait();
												window.location.reload();
											} 
										});
								}
								else {
									Swal.fire({ title: "Attention", text: arMsg[1],icon: "warning",})
// since delete is one by one it's no need
//										.then((result) => {
//											if (result.isConfirmed) { 
//												pleaseWait();
//												window.location.reload();
//											} 
//										});
								}
							} else {
								mySwal("Error",msg+".\nMohon coba lagi...","error");
							}
						}, error: function() { 
							mySwal("Attention","Demi stabilitas data, saat ini tidak diperkenankan untuk penghapusan data lewat aplikasi.\nSilahkan hubungi web administrator.","warning");
						} 
					});
				}
			}

			function pleaseWait() {
				Swal.close();
				Swal.fire({
				  title: 'Please wait',
				  html: 'Please wait while reload the page',
				  didOpen: () => {
					Swal.showLoading()
				  },
				})				

			}

			function mySwal(title,text,icon) {
				Swal.close();
				Swal.fire({
				  title: title,
				  text: text,
				  icon: icon
				});
			}
			function substrLeft(str,n){
				if(n <= 0)
					return "";
				else if(n > String(str).length)
					return str;
				else
					return String(str).substring(0,n);
			}
			function substrRight(str, n){
				if (n <= 0)
				   return "";
				else if (n > String(str).length)
				   return str;
				else {
				   var iLen = String(str).length;
				   return String(str).substring(iLen, iLen - n);
				}
			}
			function clearChar(str,chr) {
				while(str.indexOf(chr)>=0)
					str = str.replace(chr,"");
				return str;	
			}

		});

$(document).on('click', '.open-modal-btn', function() {
			var isi = $(this).data('isi'); // Ambil isi pesan
			var dokumen = $(this).data('dokumen'); // Ambil dokumen pertama
			var tglagenda = $(this).data('tglagenda'); // Ambil tanggal agenda (YYYY-MM-DD format)

			console.log("TglAgenda dari tombol:", tglagenda); // Debugging

			// Jika ada TglAgenda, set sebagai default value untuk tanggal di datetime-local
			let formattedDateTime = "";
			if (tglagenda) {
				let agendaDate = new Date(tglagenda);
				let formattedDate = agendaDate.toISOString().slice(0, 10); // Format YYYY-MM-DD
				formattedDateTime = formattedDate + "T00:00"; // Waktu default 00:00, user bisa ubah
			}

			// Isi form modal
			$('#formModal #message').val(isi); // Set Perihal sebagai pesan
			$('#formModal #url').val(dokumen);
			$('#formModal #schedule').val(formattedDateTime); // Set tanggal, user pilih waktu sendiri
		});

		$('#fonnteForm').submit(function(e) {
			e.preventDefault(); // Prevent the form from submitting traditionally

			// Ambil nilai input schedule (datetime-local) dari user
			const scheduleDateTime = $('#schedule').val(); // Format: YYYY-MM-DDTHH:MM
			let scheduleTimestamp = 0;
			if (scheduleDateTime) {
				scheduleTimestamp = Math.floor(new Date(scheduleDateTime).getTime() / 1000); // Konversi ke UNIX timestamp (detik)
			}

			const target = $('#target').val();
			const isi = $('#message').val();
			const url = $('#url').val();
			const filename = $('#filename').val();
			const delay = $('#delay').val();
			const countryCode = $('#countryCode').val();

			const cleanMessage = isi.replace(/<\/?[^>]+(>|$)/g, ""); // Hapus HTML tags dari pesan

			// Buat pesan detail
			let detailedMessage = `Reminder:\n\n`;
			detailedMessage += `*Isi Pesan:*\n`;
			detailedMessage += `${isi}\n\n`;
			detailedMessage += `*Dokumen:* ${filename}\n`;

			// Jika ada URL dokumen, tambahkan
			if (url) {
				detailedMessage += `*Link Dokumen:* ${url}\n\n`;
			}

			detailedMessage += `_Pesan ini dikirim dari Aplikasi ASIAB BAZNAS Kendal._ `;

			// Kumpulkan data form
			const formData = new FormData();
			formData.append("target", target);
			formData.append("message", detailedMessage);
			formData.append("url", url);
			formData.append("filename", filename);
			formData.append("schedule", scheduleTimestamp);
			formData.append("delay", delay);
			formData.append("countryCode", countryCode);

			// Debugging console log
			console.log("Form Data to be sent:", {
				target: target,
				message: detailedMessage,
				url: url,
				filename: filename,
				schedule: scheduleTimestamp,
				delay: delay,
				countryCode: countryCode,
			});

			// Kirim data ke API Fonnte
			fetch('https://api.fonnte.com/send', {
					method: 'POST',
					headers: {
						'Authorization': '!uDX9u#aTN7tV#@W8FLL' // Ganti dengan API token asli
					},
					body: formData
				})
				.then(response => response.json())
				.then(data => {
					if (data.status === true) {
						console.log('Success:', data);
						alert('Message Sent Successfully!');
						location.reload();
					} else {
						console.error('Failed:', data);
						alert('Failed to Send Message: ' + data.message);
					}
				})
				.catch(error => {
					console.error('Error:', error);
					alert('Failed to Send Message due to a network or server error.');
				});
		});    
    </script>
