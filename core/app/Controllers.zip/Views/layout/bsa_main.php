<?= $this->extend('layout/bsa') ?>
<?= $this->section('bsa_main') ?>
<?php 
//	 include($MainContent);
?>
<?= $this->renderSection('main') ?>
<?= $this->endSection() ?>