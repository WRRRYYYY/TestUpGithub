<?php  
	$KodeUser = $_POST["id"]; 
	$Params = "'" . $KodeUser. "'";
	echo $Params;
	?>
