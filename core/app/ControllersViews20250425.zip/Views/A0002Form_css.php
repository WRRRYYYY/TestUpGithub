    <!--<link rel="stylesheet" href="<?php echo base_url() ?>/plugins/select2/css/select2.min.css" type="text/css" />-->
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  	<link rel="stylesheet" href="<?php echo base_url() ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  	<link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.8/css/fixedHeader.dataTables.min.css">
    <!-- Cropper CSS -->
    <link href="<?php echo base_url() ?>/plugins/cropper/cropper.min.css" rel="stylesheet">
    <style>
	#datatable, #datatable2 { min-width:100%; }
	.customtab { font-size:14px; }
	.customtab .nav-item a.nav-link { padding-left:10px; padding-right:10px; }
	
	#page-form label {
	  color:#666; 
	}
	#table-hak-akses { width:100%; min-width:100%; max-width:100%; font-size:13px;  }
	.form-control, .select2 { color:#666; }
	.form-control-sm { height: 31px !important; font-size:13px !important; }
	.control-label { line-height:31px !important; }
	
	.disabled {
	  cursor: not-allowed;
	  pointer-events: all !important;
	}

  </style>
