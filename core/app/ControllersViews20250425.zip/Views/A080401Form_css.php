  <!-- Glyphicon -->
  <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/icons/glyphicon/glyphicon.css">

  <link href="<?php echo base_url() ?>/plugins/summernote/dist/summernote-bs4.css" rel="stylesheet" />

  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/daterangepicker/daterangepicker.css">
  <!--<link rel="stylesheet" href="<?php echo base_url() ?>/plugins/select2/css/select2.min.css" type="text/css" />-->
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/timepicker/bootstrap-timepicker.min.css?<?php echo rand() ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.8/css/fixedHeader.dataTables.min.css">
  <!-- File Upload -->
  <link href="<?php echo base_url() ?>/assets/css/file-upload.css" rel="stylesheet">
  <!-- Cropper CSS -->
  <link href="<?php echo base_url() ?>/plugins/cropper/cropper.min.css" rel="stylesheet">
  <!-- image-uploader -->
  <link rel="stylesheet" href="<?php echo base_url() ?>/plugins/image-uploader/image-uploader.min.css">
  <!-- Link CSS Tagify -->
  <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify@4.6.0/dist/tagify.css" rel="stylesheet" />
  <!--jodit text editor 	-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/jodit@3.24.2/build/jodit.min.css">
  <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,700|Montserrat:300,400,500,600,700|Source+Code+Pro&display=swap"
  	rel="stylesheet">
  <style>
  	#datatable {
  		min-width: 100% !important;
  	}

  	.customtab {
  		font-size: 14px;
  	}

  	.customtab .nav-item a.nav-link {
  		padding-left: 10px;
  		padding-right: 10px;
  	}

  	#page-form label {
  		color: #666;
  		line-height: 36px;
  	}

  	#table-hak-akses {
  		width: 100%;
  		min-width: 100%;
  		max-width: 100%;
  		font-size: 13px;
  	}

  	.form-control,
  	.select2 {
  		color: #666;
  	}

  	.form-control-sm {
  		height: 31px !important;
  		font-size: 13px !important;
  	}

  	.control-label {
  		line-height: 36px !important;
  	}

  	.form-group {
  		margin-bottom: 0;
  	}

  	.disabled {
  		cursor: not-allowed;
  		pointer-events: all !important;
  	}

  	.swal-button {
  		min-width: 110px !important;
  		/* Pastikan semua tombol memiliki lebar yang sama */
  		padding: 8px 12px !important;
  		/* Pastikan padding seragam */
  		font-size: 14px !important;
  		/* Sesuaikan ukuran font */
  	}

  	.swal2-confirm:focus,
  	.swal2-deny:focus,
  	.swal2-cancel:focus {
  		box-shadow: none !important;
  		/* Hapus efek border */
  		outline: none !important;
  		/* Hapus outline browser */
  	}
	
  </style>